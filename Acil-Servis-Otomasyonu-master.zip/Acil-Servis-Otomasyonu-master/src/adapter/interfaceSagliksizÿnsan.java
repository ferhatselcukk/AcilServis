/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author LENOVO
 */
public interface interfaceSagliksizİnsan {
    public String atesVAR();

    public String oksurukVAR();

    public String halsizlikVAR();

    public String nefesDarligiVAR();

}
