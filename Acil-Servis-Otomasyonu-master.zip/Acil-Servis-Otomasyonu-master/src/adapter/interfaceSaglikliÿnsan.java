
package adapter;

public interface interfaceSaglikliİnsan {
    public String atesYOK();

    public String oksurukYOK();

    public String halsizlikYOK();

    public String nefesDarligiYOK();

}
